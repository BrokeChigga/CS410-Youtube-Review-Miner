// VIPS is no longer supported


// switch to vips tree from dom
// Mousetrap.bind(['command+shift+v', 'ctrl+shift+v'], function(e, combo) {
//     console.log("HOTKEY " + combo);
//     chrome.runtime.sendMessage({type: "hotkey", event: "ctrl+shift+v"}, function(response) {
//         console.log("HOTKEY " + combo + ". Extension responded with " + response);
//     });
//     return false;
// });