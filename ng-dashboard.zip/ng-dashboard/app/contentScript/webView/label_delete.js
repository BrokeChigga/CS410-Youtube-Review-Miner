/**
 * Created by Herbert on 10/11/2017.
 */
function doFunction(e){
    console.log("label_delete_js");
    $(e.target).hide();
}